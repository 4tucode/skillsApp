const skills = [
    {
        imagen: 'https://blog.underc0de.org/wp-content/uploads/2020/09/HTML5.jpg',
        nombre:'HTML 5',
        descripcion: 'es la base y la clave de toda página web. tengo un conocimiento del 100% del lenguaje.'
    },
    {
        imagen: 'https://www.loginworks.com/wp-content/uploads/2017/12/sass-a-revolution-in-css-world-2.jpg',
        nombre:'SASS',
        descripcion: 'Es una de mis favoritos, me encanta lo fácil y bonito que queda el código, digamos que los omino un 80%.'
    },
    {
        imagen: 'https://wallpapers.com/images/hd/java-script-logoon-dark-wood-background-7yyxqxekizvuj4vg.jpg',
        nombre:'JAVASCRIPT',
        descripcion: 'Es la clave para mi, el lenguaje con el que más cómodo me siento, puedo hacer de todo con Javascript.'
    },
    {
        imagen: 'https://wallpapercave.com/wp/wp7134662.jpg',
        nombre:'VUE JS',
        descripcion: 'De todos los Frameworks con lso que he trabajado, este con diferencia es el que más me gusta.'
    },
]
let botones = document.querySelectorAll('.myButton')
const [anterior, siguiente] = botones
let cont = 0
if (cont == 0){
    anterior.setAttribute('disabled', 'true')
}else if (cont == 3){
    siguiente.setAttribute('disabled', 'true')
}
anterior.addEventListener('click', ()=>{
    cont--
    console.log('====================================');
    console.log(cont);
    console.log('====================================');
    if (cont < 0){
        cont = 0
    }
    if (cont < 3){
        siguiente.removeAttribute('disabled')
    }
    if (cont == 0){
        anterior.setAttribute('disabled', 'true')
    }else if (cont == 3){
        siguiente.setAttribute('disabled', 'true')
    }
    document.querySelector('.box-image').innerHTML = `
        <img src="${skills[cont].imagen}" alt="${skills[cont].nombre}">    
    `
    document.querySelector('.titulo').innerHTML = `
        <h2 class="titulo">${skills[cont].nombre}</h2>  
    `
    document.querySelector('.descripcion').innerHTML = `
        <p class="descripcion">${skills[cont].descripcion}</p>  
    `
})

siguiente.addEventListener('click', ()=>{
    cont++
    console.log('====================================');
    console.log(cont);
    console.log('====================================');
    if (cont > 0){
        anterior.removeAttribute('disabled')
    }
    if (cont == 0){
        anterior.setAttribute('disabled', 'true')
    }else if (cont == 3){
        siguiente.setAttribute('disabled', 'true')
    }
    document.querySelector('.box-image').innerHTML = `
        <img src="${skills[cont].imagen}" alt="${skills[cont].nombre}">    
    `
    document.querySelector('.titulo').innerHTML = `
        <h2 class="titulo">${skills[cont].nombre}</h2>  
    `
    document.querySelector('.descripcion').innerHTML = `
        <p class="descripcion">${skills[cont].descripcion}</p>  
    `
})